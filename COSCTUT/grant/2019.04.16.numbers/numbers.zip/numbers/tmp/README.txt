Output folder for the maths_is_gross tests. Do not put anything in here you don't want deleted.
